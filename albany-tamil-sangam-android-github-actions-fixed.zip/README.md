# Albany Tamil Sangam Android App

This is a ready-to-open Android Studio project that wraps the Albany Tamil Sangam website:

- Website: https://nyalbanytamilsangam.org
- App name: Albany Tamil Sangam
- Language: Kotlin
- Minimum Android version: Android 7.0 (API 24)

## Included features

- Full-screen Android WebView app
- Pull to refresh
- Back button navigation
- File upload support from web forms
- Download handling with Android DownloadManager
- Open external links in the browser
- Share current page
- Error state with retry

## How to build APK

1. Open this folder in Android Studio Hedgehog or newer.
2. Let Gradle sync complete.
3. Run on a device or emulator.
4. For an installable APK, use **Build > Build APK(s)**.

## Notes

- I could not generate a signed APK inside this environment because the Android SDK/build tools are not available here.
- The project is ready for you to import and build immediately in Android Studio.
- If you want, the next step can be a **true native app UI** instead of a website wrapper.


## Build APK on GitHub (no Android Studio)
1. Upload this project to a new GitHub repository.
2. Open the repository on GitHub.
3. Go to **Actions**.
4. Run **Build Android APK**.
5. When it finishes, open the workflow run and download the artifact named **albany-tamil-sangam-debug-apk**.
6. Inside that artifact is `app-debug.apk`.
